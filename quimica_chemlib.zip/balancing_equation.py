
from chemlib import Reaction

# Crear una ecuación desequilibrada
reaction = Reaction({"Fe": 1, "O2": 1}, {"Fe2O3": 1})  # Ejemplo: Fe + O2 -> Fe2O3

# Balancear la ecuación
reaction.balance()

# Mostrar ecuación balanceada
print("Ecuación balanceada:", reaction.formula)
