
from chemlib import Compound

# Crear un compuesto químico
compound = Compound("CO2")  # Dióxido de carbono

# Calcular la masa molar
print("Fórmula química:", compound.formula)
print("Masa molar (g/mol):", compound.molar_mass)
