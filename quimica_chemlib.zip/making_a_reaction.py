
from chemlib import Reaction

# Definir una reacción química
reaction = Reaction({"C": 1, "O2": 1}, {"CO2": 1})  # C + O2 -> CO2

# Información básica de la reacción
print("Reactivos:", reaction.reactants)
print("Productos:", reaction.products)
