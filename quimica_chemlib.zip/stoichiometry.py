
from chemlib import Reaction

# Definir una reacción química
reaction = Reaction({"H2": 2, "O2": 1}, {"H2O": 2})  # 2H2 + O2 -> 2H2O

# Calcular moles de reactivos y productos
reactants = {"H2": 4, "O2": 2}  # en moles
products = reaction.get_products(reactants)

print("Reactivos (en moles):", reactants)
print("Productos formados (en moles):", products)
