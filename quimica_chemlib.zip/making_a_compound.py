
from chemlib import Compound

# Definir un compuesto químico (por ejemplo, agua)
compound = Compound("H2O")

# Información del compuesto
print("Fórmula química:", compound.formula)
print("Masa molar (g/mol):", compound.molar_mass)
