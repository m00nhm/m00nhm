
from chemlib import Compound

# Crear un compuesto químico
compound = Compound("C6H12O6")  # Glucosa

# Obtener la composición porcentual en masa
percentage_composition = compound.mass_percent
print("Composición porcentual en masa:", percentage_composition)
